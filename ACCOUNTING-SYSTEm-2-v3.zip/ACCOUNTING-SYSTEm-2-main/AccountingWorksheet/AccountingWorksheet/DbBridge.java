import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Properties;

/**
 * BRIDGE 1 - the database bridge (Java -> MySQL Connector/J).
 *
 * The only file that talks to MySQL (or to the built-in demo data when started with --demo).
 * Main.java never sees a SQL statement.
 *
 *   - Connection settings are the constants just below (no config file).
 *   - The MySQL driver (lib/mysql-connector-j-*.jar) is found automatically, even when the
 *     program is started from an editor without the jar on the classpath.
 *   - The first time it runs it creates the database and tables from ONE file: accounting_db.sql.
 */
public final class DbBridge {

    // =================================================================== SETTINGS (edit here)
    // Any of these can also be overridden when starting Java, e.g.  java -Ddb.password=secret ...
    private static final String DB_HOST     = "localhost";
    private static final String DB_PORT     = "3306";
    private static final String DB_NAME     = "accounting_db";
    private static final String DB_USER     = "root";
    private static final String DB_PASSWORD = "25170374p";

    private static final String SQL_FILE     = "accounting_db.sql";
    private static final String DRIVER_CLASS = "com.mysql.cj.jdbc.Driver";
    // serverTimezone=UTC avoids "server time zone value ... is unrecognized" on Windows PCs.
    private static final String URL_OPTIONS =
            "sslMode=DISABLED&allowPublicKeyRetrieval=true&serverTimezone=UTC&characterEncoding=UTF-8";

    // =================================================================== DATA TYPES
    /** One account of the (fixed) chart of accounts. */
    public static final class Acct {
        public final String code, title, type, side;   // type: ASSET..EXPENSE, side: DEBIT/CREDIT

        public Acct(String code, String title, String type, String side) {
            this.code = code; this.title = title; this.type = type; this.side = side;
        }

        /** Revenue and expense accounts go to the Income Statement, the rest to the Balance Sheet. */
        public boolean income() { return type.equals("REVENUE") || type.equals("EXPENSE"); }
    }

    /** One journal line together with its entry header. */
    public static final class Line {
        public int entryId;
        public LocalDate date;
        public String desc;
        public boolean adjusting;
        public String code, title;
        public BigDecimal dr, cr;

        public Line(int entryId, LocalDate date, String desc, boolean adjusting,
                    String code, String title, BigDecimal dr, BigDecimal cr) {
            this.entryId = entryId; this.date = date; this.desc = desc; this.adjusting = adjusting;
            this.code = code; this.title = title; this.dr = dr; this.cr = cr;
        }
    }

    public static final class DataException extends RuntimeException {
        public DataException(String msg, Throwable cause) { super(msg, cause); }
    }

    // =================================================================== STATE
    private static boolean demo;
    private static String host, port, dbName, user, password;
    private static Driver driver;
    private static final List<Line> demoLines = new ArrayList<>();
    private static int demoNext = 1;

    private DbBridge() { }

    // =================================================================== SETUP
    public static synchronized void init(boolean demoMode) {
        demo = demoMode;
        if (demo) {
            if (demoLines.isEmpty()) seedDemo();
            return;
        }
        host = System.getProperty("db.host", DB_HOST).trim();
        port = System.getProperty("db.port", DB_PORT).trim();
        dbName = System.getProperty("db.name", DB_NAME).trim();
        user = System.getProperty("db.user", DB_USER);
        password = System.getProperty("db.password", DB_PASSWORD);
        if (!dbName.matches("[A-Za-z0-9_]+")) {
            throw new DataException("Database name \"" + dbName + "\" is not allowed (letters, digits and _ only).", null);
        }
        driver = loadDriver();
    }

    public static boolean isDemo() { return demo; }

    public static String describe() {
        return demo ? "Demo mode (nothing is saved)" : (host == null ? "" : "MySQL " + host + ":" + port + "/" + dbName);
    }

    /**
     * Connects (and prepares the database on first run). Throws a DataException with a readable
     * message when MySQL cannot be reached or the login is wrong.
     */
    public static synchronized void ping() {
        if (demo) return;
        try {
            if (!schemaReady()) runSetupScript();
        } catch (SQLException ex) {
            throw new DataException(explain(ex), ex);
        }
    }

    // =================================================================== DRIVER
    /**
     * Finds the MySQL JDBC driver. First the normal classpath; if it is not there (for example the
     * program was started with an editor's Run button) the jar in the lib folder is loaded directly.
     */
    private static Driver loadDriver() {
        try {
            return (Driver) Class.forName(DRIVER_CLASS).getDeclaredConstructor().newInstance();
        } catch (ReflectiveOperationException | LinkageError notOnClasspath) {
            // fall through and search the lib folders
        }
        StringBuilder looked = new StringBuilder();
        List<URL> jars = new ArrayList<>();
        for (File lib : candidateDirs("lib")) {
            looked.append("\n   ").append(lib.getAbsolutePath());
            File[] found = lib.listFiles((d, n) -> n.toLowerCase().endsWith(".jar"));
            if (found == null || found.length == 0) continue;
            try {
                for (File f : found) jars.add(f.toURI().toURL());
            } catch (MalformedURLException ignored) { /* skip an unreadable path */ }
            break;
        }
        if (jars.isEmpty()) {
            throw new DataException("The MySQL driver (mysql-connector-j-8.4.0.jar) was not found.\n"
                    + "Put it in a folder named lib next to the program. Looked in:" + looked, null);
        }
        try {
            URLClassLoader loader = new URLClassLoader(jars.toArray(new URL[0]), DbBridge.class.getClassLoader());
            return (Driver) Class.forName(DRIVER_CLASS, true, loader).getDeclaredConstructor().newInstance();
        } catch (ReflectiveOperationException | LinkageError ex) {
            throw new DataException("Found the jar in lib/ but could not start the MySQL driver: " + ex, ex);
        }
    }

    /** The given sub-folder (or file) name next to the working folder, the program, and up to 3 levels above. */
    private static List<File> candidateDirs(String name) {
        java.util.Set<File> out = new java.util.LinkedHashSet<>();
        out.add(new File(name).getAbsoluteFile());
        try {
            File loc = new File(DbBridge.class.getProtectionDomain().getCodeSource().getLocation().toURI());
            File dir = loc.isDirectory() ? loc : loc.getParentFile();
            for (int i = 0; dir != null && i < 4; i++, dir = dir.getParentFile()) out.add(new File(dir, name).getAbsoluteFile());
        } catch (Exception ignored) { /* use the remaining candidates */ }
        return new ArrayList<>(out);
    }

    // =================================================================== CONNECTIONS
    private static String urlFor(boolean withDatabase) {
        return "jdbc:mysql://" + host + ":" + port + "/" + (withDatabase ? dbName : "") + "?" + URL_OPTIONS;
    }

    private static Connection connect(boolean withDatabase) throws SQLException {
        Properties p = new Properties();
        p.setProperty("user", user);
        p.setProperty("password", password == null ? "" : password);
        Connection c = driver.connect(urlFor(withDatabase), p);
        if (c == null) throw new SQLException("The MySQL driver rejected the connection URL.");
        return c;
    }

    private static Connection open() throws SQLException { return connect(true); }

    // =================================================================== FIRST-RUN SETUP
    /** True when the database, all three tables and the chart of accounts are in place. */
    private static boolean schemaReady() throws SQLException {
        try (Connection c = open(); Statement st = c.createStatement()) {
            int accounts = count(st, "accounts");
            count(st, "journal_entries");          // only to prove that the table exists
            count(st, "journal_lines");
            return accounts > 0;
        } catch (SQLException ex) {
            if (isUnknownDatabase(ex) || isUnknownTable(ex)) return false;
            throw ex;
        }
    }

    private static int count(Statement st, String table) throws SQLException {
        try (ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM " + table)) {
            return rs.next() ? rs.getInt(1) : 0;
        }
    }

    private static boolean isUnknownDatabase(SQLException ex) { return ex.getErrorCode() == 1049; }

    private static boolean isUnknownTable(SQLException ex) { return ex.getErrorCode() == 1146 || "42S02".equals(ex.getSQLState()); }

    /** Runs accounting_db.sql (create database + tables + chart of accounts). Safe to run again. */
    private static void runSetupScript() throws SQLException {
        File script = null;
        StringBuilder looked = new StringBuilder();
        for (File f : candidateDirs(SQL_FILE)) {
            looked.append("\n   ").append(f.getAbsolutePath());
            if (f.isFile()) { script = f; break; }
        }
        if (script == null) {
            throw new DataException("The database is empty and the setup file " + SQL_FILE + " was not found. Looked in:"
                    + looked + "\n\nPut " + SQL_FILE + " next to the program, or run it once in MySQL Workbench.", null);
        }
        String text;
        try {
            text = new String(Files.readAllBytes(script.toPath()), StandardCharsets.UTF_8);
        } catch (IOException ex) {
            throw new DataException("Could not read " + script.getAbsolutePath() + ": " + ex.getMessage(), ex);
        }
        if (text.startsWith("﻿")) text = text.substring(1);
        try (Connection c = connect(false); Statement st = c.createStatement()) {   // server level: the database may not exist yet
            for (String sql : splitSql(text)) {
                try {
                    st.execute(sql);
                } catch (SQLException ex) {
                    String first = sql.length() > 90 ? sql.substring(0, 90).replace('\n', ' ') + "..." : sql.replace('\n', ' ');
                    throw new DataException("Setup script " + SQL_FILE + " failed at:\n   " + first + "\n\n" + explain(ex), ex);
                }
            }
        }
        if (!schemaReady()) {
            throw new DataException("The setup script ran, but the tables are still missing. Check that the MySQL user \""
                    + user + "\" is allowed to create the database " + dbName + ".", null);
        }
    }

    /** Splits a SQL script into statements: understands -- and # and block comments, quotes, and ';'. */
    static List<String> splitSql(String s) {
        List<String> out = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        int n = s.length();
        for (int i = 0; i < n; i++) {
            char ch = s.charAt(i);
            if (ch == '-' && i + 1 < n && s.charAt(i + 1) == '-') {            // -- comment
                while (i < n && s.charAt(i) != '\n') i++;
                cur.append('\n');
            } else if (ch == '#') {                                            // # comment
                while (i < n && s.charAt(i) != '\n') i++;
                cur.append('\n');
            } else if (ch == '/' && i + 1 < n && s.charAt(i + 1) == '*') {     // /* block comment */
                int end = s.indexOf("*/", i + 2);
                i = end < 0 ? n : end + 1;
                cur.append(' ');
            } else if (ch == '\'' || ch == '"' || ch == '`') {                 // quoted text, '' and \' allowed inside
                cur.append(ch);
                i++;
                while (i < n) {
                    char q = s.charAt(i);
                    cur.append(q);
                    if (q == '\\' && ch != '`' && i + 1 < n) { cur.append(s.charAt(++i)); }
                    else if (q == ch) {
                        if (i + 1 < n && s.charAt(i + 1) == ch) { cur.append(s.charAt(++i)); }
                        else break;
                    }
                    i++;
                }
            } else if (ch == ';') {
                addStatement(out, cur);
            } else {
                cur.append(ch);
            }
        }
        addStatement(out, cur);
        return out;
    }

    private static void addStatement(List<String> out, StringBuilder cur) {
        String t = cur.toString().trim();
        if (!t.isEmpty()) out.add(t);
        cur.setLength(0);
    }

    // =================================================================== FRIENDLY ERRORS
    private static String explain(SQLException ex) {
        String msg = ex.getMessage() == null ? ex.toString() : ex.getMessage();
        String first = msg.split("\n")[0];
        String where = host + ":" + port;
        String help;
        if (ex.getErrorCode() == 1045) {
            help = "MySQL refused the login. The user name or password is wrong.\n"
                 + "Fix DB_USER / DB_PASSWORD at the top of DbBridge.java.";
        } else if (isUnknownDatabase(ex)) {
            help = "The database \"" + dbName + "\" does not exist and could not be created.";
        } else if (ex.getErrorCode() == 1044 || ex.getErrorCode() == 1142) {
            help = "This MySQL user is not allowed to create or use the database. Use a user with enough rights (e.g. root).";
        } else if (msg.contains("Communications link failure") || "08S01".equals(ex.getSQLState())
                || ex.getCause() instanceof java.net.ConnectException) {
            help = "MySQL is not answering at " + where + ".\n"
                 + "Start MySQL (Windows: Services > MySQL80, or XAMPP > MySQL > Start) and check DB_HOST / DB_PORT in DbBridge.java.";
        } else if (msg.contains("time zone")) {
            help = "MySQL's time zone setting was not recognised by the driver.";
        } else {
            help = "Check that MySQL is running and the settings at the top of DbBridge.java are right.";
        }
        return "Cannot connect to MySQL (" + where + "):\n" + first + "\n\n" + help;
    }

    private static DataException fail(String what, SQLException ex) {
        return new DataException(what + ": " + (ex.getMessage() == null ? ex.toString() : ex.getMessage().split("\n")[0]), ex);
    }

    // =================================================================== READ
    public static List<Acct> accounts() {
        if (demo) return demoAccounts();
        List<Acct> list = new ArrayList<>();
        try (Connection c = open();
             PreparedStatement ps = c.prepareStatement(
                     "SELECT account_code, account_title, account_type, normal_side FROM accounts ORDER BY account_code");
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                list.add(new Acct(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4)));
            }
            return list;
        } catch (SQLException ex) {
            throw fail("Could not load the chart of accounts", ex);
        }
    }

    public static List<Line> lines(LocalDate from, LocalDate to) {
        List<Line> list = new ArrayList<>();
        if (demo) {
            for (Line l : demoLines) {
                if (!l.date.isBefore(from) && !l.date.isAfter(to)) list.add(l);
            }
            list.sort(Comparator.comparing((Line l) -> l.date).thenComparingInt(l -> l.entryId));
            return list;
        }
        String sql = "SELECT e.entry_id, CAST(e.entry_date AS CHAR), e.description, e.entry_type, "
                + "l.account_code, a.account_title, l.debit, l.credit "
                + "FROM journal_entries e JOIN journal_lines l ON l.entry_id = e.entry_id "
                + "JOIN accounts a ON a.account_code = l.account_code "
                + "WHERE e.entry_date BETWEEN ? AND ? ORDER BY e.entry_date, e.entry_id, l.line_id";
        try (Connection c = open(); PreparedStatement ps = c.prepareStatement(sql)) {
            // dates travel as plain yyyy-MM-dd text, so the PC's and the server's time zones can never shift a day
            ps.setString(1, from.toString());
            ps.setString(2, to.toString());
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    String d = rs.getString(2);
                    list.add(new Line(rs.getInt(1), LocalDate.parse(d.substring(0, 10)), rs.getString(3),
                            "ADJUSTING".equals(rs.getString(4)), rs.getString(5), rs.getString(6),
                            rs.getBigDecimal(7), rs.getBigDecimal(8)));
                }
            }
            return list;
        } catch (SQLException ex) {
            throw fail("Could not load the journal", ex);
        }
    }

    // =================================================================== WRITE
    /** Saves header + lines in ONE transaction. Only code/dr/cr of each line are used. Returns the entry id. */
    public static int saveEntry(LocalDate date, String desc, boolean adjusting, List<Line> ls) {
        if (demo) {
            int id = demoNext++;
            for (Line l : ls) {
                demoLines.add(new Line(id, date, desc, adjusting, l.code, titleOf(l.code), l.dr, l.cr));
            }
            return id;
        }
        try (Connection c = open()) {
            c.setAutoCommit(false);
            try {
                int id;
                try (PreparedStatement ps = c.prepareStatement(
                        "INSERT INTO journal_entries (entry_date, description, entry_type) VALUES (?,?,?)",
                        Statement.RETURN_GENERATED_KEYS)) {
                    ps.setString(1, date.toString());
                    ps.setString(2, desc);
                    ps.setString(3, adjusting ? "ADJUSTING" : "REGULAR");
                    ps.executeUpdate();
                    try (ResultSet keys = ps.getGeneratedKeys()) {
                        if (!keys.next()) throw new SQLException("No entry id was generated.");
                        id = keys.getInt(1);
                    }
                }
                try (PreparedStatement ps = c.prepareStatement(
                        "INSERT INTO journal_lines (entry_id, account_code, debit, credit) VALUES (?,?,?,?)")) {
                    for (Line l : ls) {
                        ps.setInt(1, id);
                        ps.setString(2, l.code);
                        ps.setBigDecimal(3, l.dr);
                        ps.setBigDecimal(4, l.cr);
                        ps.addBatch();
                    }
                    ps.executeBatch();
                }
                c.commit();
                return id;
            } catch (SQLException ex) {
                c.rollback();                 // header and lines are saved together or not at all
                throw ex;
            }
        } catch (SQLException ex) {
            throw fail("Could not save the entry", ex);
        }
    }

    public static void deleteEntry(int id) {
        if (demo) {
            demoLines.removeIf(l -> l.entryId == id);
            return;
        }
        try (Connection c = open();
             PreparedStatement ps = c.prepareStatement("DELETE FROM journal_entries WHERE entry_id = ?")) {
            ps.setInt(1, id);
            ps.executeUpdate();            // lines go away through ON DELETE CASCADE
        } catch (SQLException ex) {
            throw fail("Could not delete the entry", ex);
        }
    }

    // =================================================================== DEMO DATA
    private static List<Acct> demoAccounts() {
        String[][] a = {
            {"1010", "Cash", "ASSET", "DEBIT"}, {"1020", "Accounts Receivable", "ASSET", "DEBIT"},
            {"1030", "Supplies", "ASSET", "DEBIT"}, {"1040", "Prepaid Insurance", "ASSET", "DEBIT"},
            {"1110", "Office Equipment", "ASSET", "DEBIT"},
            {"1120", "Accumulated Depreciation - Office Equipment", "ASSET", "CREDIT"},
            {"2010", "Accounts Payable", "LIABILITY", "CREDIT"}, {"2020", "Salaries Payable", "LIABILITY", "CREDIT"},
            {"3010", "Owner's Capital", "EQUITY", "CREDIT"}, {"3020", "Owner's Drawings", "EQUITY", "DEBIT"},
            {"4010", "Service Revenue", "REVENUE", "CREDIT"},
            {"5010", "Salaries Expense", "EXPENSE", "DEBIT"}, {"5020", "Utilities Expense", "EXPENSE", "DEBIT"},
            {"5030", "Supplies Expense", "EXPENSE", "DEBIT"}, {"5040", "Insurance Expense", "EXPENSE", "DEBIT"},
            {"5050", "Depreciation Expense", "EXPENSE", "DEBIT"}};
        List<Acct> list = new ArrayList<>();
        for (String[] r : a) list.add(new Acct(r[0], r[1], r[2], r[3]));
        return list;
    }

    private static String titleOf(String code) {
        for (Acct a : demoAccounts()) if (a.code.equals(code)) return a.title;
        return code;
    }

    private static void seedDemo() {
        Object[][] e = {
            {"2026-10-01", "Owner invested cash in the business", false, "1010", 100000, "3010"},
            {"2026-10-02", "Purchased supplies on account", false, "1030", 6000, "2010"},
            {"2026-10-03", "Paid one-year insurance premium", false, "1040", 12000, "1010"},
            {"2026-10-05", "Purchased office equipment for cash", false, "1110", 40000, "1010"},
            {"2026-10-10", "Received cash for services rendered", false, "1010", 30000, "4010"},
            {"2026-10-15", "Services rendered on account", false, "1020", 20000, "4010"},
            {"2026-10-20", "Paid salaries", false, "5010", 15000, "1010"},
            {"2026-10-22", "Paid utilities", false, "5020", 3000, "1010"},
            {"2026-10-25", "Paid part of accounts payable", false, "2010", 2000, "1010"},
            {"2026-10-28", "Owner withdrew cash for personal use", false, "3020", 5000, "1010"},
            {"2026-10-31", "Adjusting: supplies used during the month", true, "5030", 4000, "1030"},
            {"2026-10-31", "Adjusting: insurance expired", true, "5040", 1000, "1040"},
            {"2026-10-31", "Adjusting: depreciation of office equipment", true, "5050", 1000, "1120"},
            {"2026-10-31", "Adjusting: accrued salaries", true, "5010", 2000, "2020"}};
        for (Object[] r : e) {
            BigDecimal amt = new BigDecimal(((Integer) r[4]).intValue()).setScale(2);
            BigDecimal zero = BigDecimal.ZERO.setScale(2);
            int id = demoNext++;
            LocalDate d = LocalDate.parse((String) r[0]);
            demoLines.add(new Line(id, d, (String) r[1], (Boolean) r[2], (String) r[3], titleOf((String) r[3]), amt, zero));
            demoLines.add(new Line(id, d, (String) r[1], (Boolean) r[2], (String) r[5], titleOf((String) r[5]), zero, amt));
        }
    }
}
