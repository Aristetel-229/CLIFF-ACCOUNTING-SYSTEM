-- ============================================================================
--  LedgerBuddy - Accounting Worksheet System  |  THE ONE MySQL FILE
--  Target: MySQL 8.0.16+  (also works on MariaDB 10.2+ / XAMPP)
--
--  You normally do NOT need to run this by hand: the app runs it by itself
--  the first time it starts and finds the database or the tables missing.
--  Running it yourself (MySQL Workbench: File > Open SQL Script > Run) is
--  safe too - every statement can be repeated without damaging existing data.
--
--  Sections:   1) database   2) tables   3) chart of accounts   4) sample data (off)
-- ============================================================================

-- ----------------------------------------------------------------------------
-- 1) DATABASE
-- ----------------------------------------------------------------------------
CREATE DATABASE IF NOT EXISTS accounting_db
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE accounting_db;

-- ----------------------------------------------------------------------------
-- 2) TABLES
-- ----------------------------------------------------------------------------

-- Chart of accounts (FIXED: loaded by this script, no add/edit/delete in the app).
-- `statement` is generated from the account type, so it can never be mistyped:
--   REVENUE / EXPENSE            -> IS (Income Statement)
--   ASSET / LIABILITY / EQUITY   -> BS (Balance Sheet)
CREATE TABLE IF NOT EXISTS accounts (
  account_code  VARCHAR(10)  NOT NULL,
  account_title VARCHAR(100) NOT NULL,
  account_type  ENUM('ASSET','LIABILITY','EQUITY','REVENUE','EXPENSE') NOT NULL,
  normal_side   ENUM('DEBIT','CREDIT') NOT NULL,
  statement     CHAR(2) AS (
                  CASE WHEN account_type IN ('REVENUE','EXPENSE') THEN 'IS' ELSE 'BS' END
                ) STORED,
  PRIMARY KEY (account_code),
  UNIQUE KEY uq_account_title (account_title)
) ENGINE=InnoDB;

-- Journal entry header. entry_type separates regular entries from adjusting
-- entries so both live in the same tables (needed for the 12-column worksheet).
CREATE TABLE IF NOT EXISTS journal_entries (
  entry_id    INT          NOT NULL AUTO_INCREMENT,
  entry_date  DATE         NOT NULL,
  description VARCHAR(255) NOT NULL,
  entry_type  ENUM('REGULAR','ADJUSTING') NOT NULL DEFAULT 'REGULAR',
  created_at  TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (entry_id),
  KEY idx_entry_date (entry_date),
  KEY idx_entry_type (entry_type)
) ENGINE=InnoDB;

-- Journal entry lines. Exactly one of debit / credit is > 0 on every line.
-- Debits = credits per entry is checked by the Java program before saving.
CREATE TABLE IF NOT EXISTS journal_lines (
  line_id      INT           NOT NULL AUTO_INCREMENT,
  entry_id     INT           NOT NULL,
  account_code VARCHAR(10)   NOT NULL,
  debit        DECIMAL(15,2) NOT NULL DEFAULT 0.00,
  credit       DECIMAL(15,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (line_id),
  KEY idx_line_account (account_code),
  CONSTRAINT fk_line_entry   FOREIGN KEY (entry_id)
      REFERENCES journal_entries (entry_id) ON DELETE CASCADE,
  CONSTRAINT fk_line_account FOREIGN KEY (account_code)
      REFERENCES accounts (account_code),
  CONSTRAINT chk_one_side CHECK (
      (debit > 0 AND credit = 0) OR (debit = 0 AND credit > 0))
) ENGINE=InnoDB;

-- ----------------------------------------------------------------------------
-- 3) CHART OF ACCOUNTS
--  *** PLACEHOLDER ***  Replace the rows below with the chart of accounts given
--  by your instructor. Keep these rules:
--    * account_type : ASSET | LIABILITY | EQUITY | REVENUE | EXPENSE
--    * normal_side  : DEBIT | CREDIT
--      (contra accounts are the opposite of their type, e.g. Accumulated
--       Depreciation = ASSET / CREDIT, Owner's Drawings = EQUITY / DEBIT)
--  The Income Statement / Balance Sheet placement is derived automatically.
--  To load a NEW chart (only while there are no journal entries) run
--  DELETE FROM accounts;  first, then this section again.
-- ----------------------------------------------------------------------------
INSERT IGNORE INTO accounts (account_code, account_title, account_type, normal_side) VALUES
-- Assets
('1010', 'Cash',                                        'ASSET',     'DEBIT'),
('1020', 'Accounts Receivable',                         'ASSET',     'DEBIT'),
('1030', 'Supplies',                                    'ASSET',     'DEBIT'),
('1040', 'Prepaid Insurance',                           'ASSET',     'DEBIT'),
('1110', 'Office Equipment',                            'ASSET',     'DEBIT'),
('1120', 'Accumulated Depreciation - Office Equipment', 'ASSET',     'CREDIT'),
-- Liabilities
('2010', 'Accounts Payable',                            'LIABILITY', 'CREDIT'),
('2020', 'Salaries Payable',                            'LIABILITY', 'CREDIT'),
-- Owner's equity
('3010', 'Owner''s Capital',                            'EQUITY',    'CREDIT'),
('3020', 'Owner''s Drawings',                           'EQUITY',    'DEBIT'),
-- Revenue
('4010', 'Service Revenue',                             'REVENUE',   'CREDIT'),
-- Expenses
('5010', 'Salaries Expense',                            'EXPENSE',   'DEBIT'),
('5020', 'Utilities Expense',                           'EXPENSE',   'DEBIT'),
('5030', 'Supplies Expense',                            'EXPENSE',   'DEBIT'),
('5040', 'Insurance Expense',                           'EXPENSE',   'DEBIT'),
('5050', 'Depreciation Expense',                        'EXPENSE',   'DEBIT');

-- ----------------------------------------------------------------------------
-- 4) OPTIONAL SAMPLE DATA (October 2026) - switched OFF.
--  To use it: delete the  /*  on the next line and the  */  at the very end
--  of the file, then run the file once. Uses the placeholder chart above.
--  Expected worksheet result:
--    Unadjusted TB 154,000.00 | Adjustments 8,000.00 | Adjusted TB 157,000.00
--    Net income 24,000.00     | Balance sheet difference 0.00
--  (Prefer to just look around?  run.bat --demo needs no database at all.)
-- ----------------------------------------------------------------------------
/*
INSERT IGNORE INTO journal_entries (entry_id, entry_date, description, entry_type) VALUES
(1,  '2026-10-01', 'Owner invested cash in the business',         'REGULAR'),
(2,  '2026-10-02', 'Purchased supplies on account',               'REGULAR'),
(3,  '2026-10-03', 'Paid one-year insurance premium',             'REGULAR'),
(4,  '2026-10-05', 'Purchased office equipment for cash',         'REGULAR'),
(5,  '2026-10-10', 'Received cash for services rendered',         'REGULAR'),
(6,  '2026-10-15', 'Services rendered on account',                'REGULAR'),
(7,  '2026-10-20', 'Paid salaries',                               'REGULAR'),
(8,  '2026-10-22', 'Paid utilities',                              'REGULAR'),
(9,  '2026-10-25', 'Paid part of accounts payable',               'REGULAR'),
(10, '2026-10-28', 'Owner withdrew cash for personal use',        'REGULAR'),
(11, '2026-10-31', 'Adjusting: supplies used during the month',   'ADJUSTING'),
(12, '2026-10-31', 'Adjusting: insurance expired',                'ADJUSTING'),
(13, '2026-10-31', 'Adjusting: depreciation of office equipment', 'ADJUSTING'),
(14, '2026-10-31', 'Adjusting: accrued salaries',                 'ADJUSTING');

INSERT INTO journal_lines (entry_id, account_code, debit, credit)
SELECT v.entry_id, v.account_code, v.debit, v.credit FROM (
  SELECT 1 AS entry_id, '1010' AS account_code, 100000.00 AS debit, 0.00 AS credit
  UNION ALL SELECT 1,  '3010',      0.00, 100000.00
  UNION ALL SELECT 2,  '1030',   6000.00,      0.00
  UNION ALL SELECT 2,  '2010',      0.00,   6000.00
  UNION ALL SELECT 3,  '1040',  12000.00,      0.00
  UNION ALL SELECT 3,  '1010',      0.00,  12000.00
  UNION ALL SELECT 4,  '1110',  40000.00,      0.00
  UNION ALL SELECT 4,  '1010',      0.00,  40000.00
  UNION ALL SELECT 5,  '1010',  30000.00,      0.00
  UNION ALL SELECT 5,  '4010',      0.00,  30000.00
  UNION ALL SELECT 6,  '1020',  20000.00,      0.00
  UNION ALL SELECT 6,  '4010',      0.00,  20000.00
  UNION ALL SELECT 7,  '5010',  15000.00,      0.00
  UNION ALL SELECT 7,  '1010',      0.00,  15000.00
  UNION ALL SELECT 8,  '5020',   3000.00,      0.00
  UNION ALL SELECT 8,  '1010',      0.00,   3000.00
  UNION ALL SELECT 9,  '2010',   2000.00,      0.00
  UNION ALL SELECT 9,  '1010',      0.00,   2000.00
  UNION ALL SELECT 10, '3020',   5000.00,      0.00
  UNION ALL SELECT 10, '1010',      0.00,   5000.00
  UNION ALL SELECT 11, '5030',   4000.00,      0.00
  UNION ALL SELECT 11, '1030',      0.00,   4000.00
  UNION ALL SELECT 12, '5040',   1000.00,      0.00
  UNION ALL SELECT 12, '1040',      0.00,   1000.00
  UNION ALL SELECT 13, '5050',   1000.00,      0.00
  UNION ALL SELECT 13, '1120',      0.00,   1000.00
  UNION ALL SELECT 14, '5010',   2000.00,      0.00
  UNION ALL SELECT 14, '2020',      0.00,   2000.00
) v
WHERE NOT EXISTS (SELECT 1 FROM journal_lines);
*/
