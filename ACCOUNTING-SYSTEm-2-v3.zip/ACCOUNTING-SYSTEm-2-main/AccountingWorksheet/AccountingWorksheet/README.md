# LedgerBuddy - Accounting Worksheet System

Yellow + blue desktop app (Java Swing + MySQL through the MySQL Connector/J driver).

```
AccountingWorksheet/
  Main.java              <- screens: Journal Entry, Chart of Accounts, Ledger, 12-column Worksheet
  DbBridge.java          <- bridge 1: the ONLY file that talks to MySQL (+ --demo data)
  ExportBridge.java      <- bridge 2: CSV export for Excel
  accounting_db.sql      <- the ONE MySQL file (database + tables + chart of accounts)
  lib/                   <- MySQL driver (mysql-connector-j) - loaded automatically
  run.bat / run.sh       <- start the app
  AccountingWorksheet.jar<- prebuilt copy (keep it next to the lib folder)
  .vscode/settings.json  <- tells VS Code about lib/ so there are no red errors
```

## Run it
1. **Just look first:** `run.bat --demo` (Windows) or `./run.sh --demo` - no database needed, nothing is saved.
2. **Real use:** start MySQL, set your password at the top of `DbBridge.java`
   (`DB_USER`, `DB_PASSWORD`; also `DB_HOST`, `DB_PORT`), then `run.bat` / `./run.sh`.
   **You do not have to run any SQL by hand** - on the first start the app creates the database
   `accounting_db`, the tables and the chart of accounts from `accounting_db.sql`.
   (You can also open that file in MySQL Workbench and run it; it is safe to run twice.)
3. If MySQL can't be reached the app shows what is wrong (not running / wrong password / ...)
   and offers Retry / Demo Mode / Exit.

### VS Code
Open the `AccountingWorksheet` folder itself (the one that contains `Main.java`) and press Run on
`Main.java`. Even without the `lib` setting the app finds the driver by itself.

## Screens (Ctrl+1 to Ctrl+4)
1. **Journal Entry** - Regular or Adjusting. Post is only enabled when Debit = Credit.
2. **Chart of Accounts** - fixed, read-only. To use your instructor's chart, replace the rows in
   section 3 of `accounting_db.sql` (account_type + normal_side) before the first run (or `DELETE FROM accounts;` and run the file again while there are no entries).
3. **Ledger** - one account or all, running balance with Dr / Cr.
4. **12-Column Worksheet** - Unadjusted TB, Adjustments, Adjusted TB, Income Statement, Balance Sheet.
   The banner shows BALANCED only when the Balance Sheet grand-total difference is **0.00**
   (net income/loss is added to the right side). Filter buttons show one section at a time.

## Quick Prompt (fastest way to enter)
Type one line and press Enter, then check and Post:

```
Dr Cash 5000, Cr Owner's Capital | Owner invested cash
Dr Supplies Expense 4000, Cr Supplies          (add  adj:  in front for an adjusting entry)
Dr 1010 2,500.50, Cr 4010                      (codes work; one line may skip its amount)
```
Account names can be partial ("cash", "owners cap"); 5k = 5000.

## Troubleshooting
| Message | Fix |
|---|---|
| MySQL is not answering at localhost:3306 | Start MySQL (Services > MySQL80, or XAMPP > MySQL > Start). |
| MySQL refused the login | Fix `DB_USER` / `DB_PASSWORD` in `DbBridge.java`. |
| MySQL driver was not found | Keep the `lib` folder (with `mysql-connector-j-8.4.0.jar`) next to the program. |
| Setup script failed at ... | Read the statement shown; the MySQL user needs the right to create databases (root has it). |

Settings can also be given without editing code: `java -cp "out;lib/*" -Ddb.password=secret Main`
(also `-Ddb.user`, `-Ddb.host`, `-Ddb.port`, `-Ddb.name`).
